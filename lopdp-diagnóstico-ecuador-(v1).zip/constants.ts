import { Question, ResultLevel } from './types';

export const QUESTIONS: Question[] = [
  {
    id: 1,
    text: "¿Su empresa o negocio cuenta con un Registro de Actividades de Tratamiento (RAT) elaborado conforme a la LOPDP y su Reglamento?",
    description: "Este es uno de los incumplimientos más comunes y de mayor riesgo."
  },
  {
    id: 2,
    text: "¿Cuenta con cláusulas de consentimiento informado en todos sus formularios?",
    description: "Físicos o digitales, asegurando que el titular autoriza explícitamente el uso de sus datos."
  },
  {
    id: 3,
    text: "¿Existen políticas de seguridad de la información y medidas técnicas mínimas implementadas?",
    description: "Controles de acceso, contraseñas seguras, doble factor de autenticación, cifrado de datos y copias de seguridad, respaldos y control de accesos.\nSon requerimientos mínimos del Reglamento."
  },
  {
    id: 4,
    text: "¿Dispone de políticas internas y avisos de privacidad actualizados y visibles para clientes, colaboradores y terceros?",
    description: "Las multas son altas si no existen o no están actualizadas."
  },
  {
    id: 5,
    text: "¿Su empresa o negocio tiene procedimientos formales para atender solicitudes de derechos ARCO (acceso, rectificación, cancelación, oposición) dentro de los plazos legales?",
    description: "Mecanismos para que los usuarios soliciten Acceso, Rectificación, Cancelación u Oposición.\nEste punto genera responsabilidad inmediata si no existe."
  },
  {
    id: 6,
    text: "¿Los contratos con proveedores y encargados del tratamiento de datos incluyen cláusulas obligatorias de protección de datos personales? ¿Se han firmado acuerdos de confidencialidad y tratamiento con proveedores?",
    description: "Un proveedor sin controles puede generar multas para su empresa.\nContratos que obliguen a terceros (encargados) a proteger los datos que les comparte."
  },
  {
    id: 7,
    text: "¿Cuenta su organización con procedimientos de gestión y reporte de incidentes de seguridad y brechas de datos?",
    description: "Protocolo para actuar en caso de hackeos, fugas de información o accesos no autorizados.\nLa LOPDP exige notificar a la Autoridad dentro de 5 días si hay un incidente."
  },
  {
    id: 8,
    text: "¿Ha realizado un Análisis de Riesgos o una Evaluación de Impacto de Protección de Datos (EIPD) para actividades de alto riesgo?",
    description: "Identificación de amenazas sobre los datos personales y medidas para mitigarlas.\nObligatorio cuando se procesan datos sensibles, biométricos, financieros, etc."
  },
  {
    id: 9,
    text: "¿Su empresa controla y limita el acceso a datos personales solo al personal estrictamente necesario, con roles y permisos definidos?",
    description: "Uno de los puntos que más brechas de seguridad genera."
  },
  {
    id: 10,
    text: "¿Han recibido sus colaboradores capacitación formal sobre protección de datos personales y buenas prácticas de seguridad?",
    description: "La autoridad exige evidencia de capacitación continua."
  },
  {
    id: 11,
    text: "¿Ha designado un Delegado de Protección de Datos (DPO) o responsable?",
    description: "Persona encargada de supervisar el cumplimiento normativo dentro de la empresa."
  },
  {
    id: 12,
    text: "¿Ha identificado formalmente las bases legales que justifican el tratamiento de cada tipo de dato personal que maneja su empresa?",
    description: "La LOPDP exige tenerlo documentado para evitar sanciones."
  }
];

export const RESULT_LEVELS: ResultLevel[] = [
  {
    min: 0,
    max: 24,
    title: "Riesgo Muy Alto",
    subtitle: "INCUMPLIMIENTO CRÍTICO",
    colorClass: "red",
    description: `Su empresa presenta incumplimientos críticos frente a la Ley Orgánica de Protección de Datos Personales y su Reglamento.
Esto la expone a multas significativas, inspecciones, reclamos de usuarios y sanciones por parte de la Autoridad de Protección de Datos.
Además, existen brechas que pueden comprometer:`,
    bulletPoints: [
      "La información de clientes y colaboradores",
      "La continuidad operativa",
      "La reputación de la organización"
    ],
    recommendation: "Requiere una intervención urgente.\nImplementación de políticas, estructura documental, controles, contratos y un análisis de riesgos completo.\nPodemos ayudarle a cumplir la normativa y evitar sanciones."
  },
  {
    min: 25,
    max: 42,
    title: "Riesgo Medio",
    subtitle: "CUMPLIMIENTO PARCIAL",
    colorClass: "orange",
    description: `Su empresa tiene algunos elementos implementados, pero incumple aspectos esenciales exigidos por la LOPDP.
Esto significa que, ante una auditoría o reclamo, podría ser sancionada.
Las principales brechas suelen estar en:`,
    bulletPoints: [
      "Registro de Actividades de Tratamiento",
      "Derechos ARCO",
      "Políticas internas",
      "Gestión de incidentes",
      "Contratos con proveedores"
    ],
    recommendation: "Requiere un Plan de Implementación de Protección de Datos para lograr un cumplimiento adecuado y reducir la exposición legal."
  },
  {
    min: 43,
    max: 54,
    title: "Riesgo Bajo",
    subtitle: "CUMPLIMIENTO ACEPTABLE",
    colorClass: "amber",
    description: `Su empresa muestra un avance considerable hacia el cumplimiento, pero aún tiene brechas relevantes, especialmente en controles técnicos y procesos obligatorios.
Aunque el nivel de madurez es superior al promedio, todavía no cumple con:`,
    bulletPoints: [
      "Requisitos formales de documentación",
      "Evaluaciones de impacto",
      "Gestión completa de riesgos",
      "Evidencias necesarias para auditoría"
    ],
    recommendation: "Realizar un Diagnóstico Profesional Completo y fortalecer las áreas con falencias para asegurar cumplimiento total y evitar sanciones."
  },
  {
    min: 55,
    max: 60,
    title: "Cumplimiento Alto",
    subtitle: "EXPUESTO A RIESGOS",
    colorClass: "emerald",
    description: `Su empresa presenta un adecuado nivel de cumplimiento inicial.
Sin embargo, la LOPDP y su Reglamento requieren evidencias técnicas, documentales y operativas que no pueden verificarse con este autodiagnóstico.
Para garantizar el cumplimiento ante una auditoría oficial, se recomienda:`,
    bulletPoints: [
      "Auditoría profesional",
      "Ajustes finales",
      "Implementación de controles avanzados",
      "Preparación hacia mejores prácticas (ISO 27001)"
    ],
    recommendation: "Realizar una auditoría de cumplimiento para validar el nivel real de madurez y obtener un informe completo con acciones de mejora."
  }
];

export const getResult = (score: number): ResultLevel => {
  return RESULT_LEVELS.find(level => score >= level.min && score <= level.max) || RESULT_LEVELS[0];
};