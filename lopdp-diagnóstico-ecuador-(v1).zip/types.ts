export interface Question {
  id: number;
  text: string;
  description: string;
}

export interface ResultLevel {
  min: number;
  max: number;
  title: string;
  subtitle: string;
  colorClass: string; // Tailwind base color name (e.g., 'red', 'orange')
  description: string;
  recommendation: string;
  bulletPoints: string[];
}

export interface Answer {
  questionId: number;
  value: number; // 1-5
}