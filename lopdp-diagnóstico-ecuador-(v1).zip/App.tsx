import React, { useState } from 'react';
import { QUESTIONS, getResult } from './constants';
import QuestionCard from './components/QuestionCard';
import ResultCard from './components/ResultCard';
import ProgressBar from './components/ProgressBar';
import ContactCard from './components/ContactCard';
import { ShieldCheck, ChevronRight } from 'lucide-react';

const App: React.FC = () => {
  const [started, setStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showResult, setShowResult] = useState(false);
  const [showContact, setShowContact] = useState(false);

  const currentQuestion = QUESTIONS[currentQuestionIndex];
  const totalQuestions = QUESTIONS.length;

  const handleAnswer = (value: number) => {
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: value
    }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      // Scroll to top when changing questions
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setShowResult(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleContactRequest = () => {
    setShowContact(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToResults = () => {
    setShowContact(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const calculateScore = () => {
    return Object.values(answers).reduce((acc, curr) => acc + curr, 0);
  };

  const resetQuiz = () => {
    setStarted(false);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setShowResult(false);
    setShowContact(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center py-8 px-4 sm:px-6 lg:px-8 bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="mb-8 md:mb-12 text-center max-w-2xl mx-auto">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="bg-blue-900 p-2.5 rounded-xl shadow-lg shadow-blue-900/20">
            <ShieldCheck className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight text-slate-900">
            Diagnóstico LOPDP Ecuador
          </h1>
        </div>
      </header>

      <main className="w-full max-w-2xl">
        {!started ? (
          // Welcome Screen
          <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/60 overflow-hidden border border-slate-100 p-8 md:p-12 text-center animate-in zoom-in-95 duration-500">
            <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mb-6 leading-tight">
              ¿Cumple su empresa con la Ley de Protección de Datos?
            </h2>
            <p className="text-lg text-slate-600 mb-10 leading-relaxed">
              La Ley Orgánica de Protección de Datos Personales (LOPDP) es obligatoria en Ecuador. 
              Realice este diagnóstico gratuito de <strong>3 minutos</strong> para conocer su nivel de riesgo y evitar sanciones.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 text-left">
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <span className="text-2xl mb-2 block">📋</span>
                <h3 className="font-bold text-slate-900 mb-1">12 Preguntas</h3>
                <p className="text-sm text-slate-500">Evaluación rápida de áreas clave.</p>
              </div>
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <span className="text-2xl mb-2 block">📊</span>
                <h3 className="font-bold text-slate-900 mb-1">Puntaje Real</h3>
                <p className="text-sm text-slate-500">Cálculo inmediato de nivel de riesgo.</p>
              </div>
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <span className="text-2xl mb-2 block">💡</span>
                <h3 className="font-bold text-slate-900 mb-1">Recomendación</h3>
                <p className="text-sm text-slate-500">Plan de acción personalizado.</p>
              </div>
            </div>

            <button 
              onClick={() => setStarted(true)}
              className="w-full md:w-auto inline-flex items-center justify-center gap-2 bg-blue-900 hover:bg-blue-800 text-white text-lg font-bold py-4 px-10 rounded-xl transition-all shadow-lg shadow-blue-900/30 transform hover:-translate-y-1"
            >
              Iniciar Diagnóstico
              <ChevronRight className="w-5 h-5" />
            </button>
            <p className="mt-6 text-xs text-slate-400">
              Este diagnóstico es referencial y no constituye asesoría legal oficial.
            </p>
          </div>

        ) : showContact ? (
          // Contact / Next Steps Screen
          <ContactCard onBack={handleBackToResults} />

        ) : showResult ? (
          // Result Screen
          <ResultCard 
            result={getResult(calculateScore())} 
            score={calculateScore()} 
            onReset={resetQuiz} 
            onContactRequest={handleContactRequest}
          />

        ) : (
          // Question Screen
          <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/60 border border-slate-100 overflow-hidden relative">
            <div className="p-6 md:p-10">
              <ProgressBar current={currentQuestionIndex + 1} total={totalQuestions} />
              
              <QuestionCard 
                question={currentQuestion} 
                onAnswer={handleAnswer} 
                onNext={handleNext}
                selectedParams={answers[currentQuestion.id]}
              />
            </div>
            
            <div className="bg-slate-50 p-4 text-center border-t border-slate-100">
              <button 
                onClick={() => {
                  if (currentQuestionIndex > 0) {
                    setCurrentQuestionIndex(prev => prev - 1);
                  } else {
                    setStarted(false);
                  }
                }}
                className="text-slate-400 hover:text-slate-600 text-sm font-medium transition-colors"
              >
                Volver a la anterior
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Footer Branding */}
      <footer className="mt-12 text-center text-slate-400 text-sm">
        <p>© {new Date().getFullYear()} Consultoría LOPDP. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
};

export default App;