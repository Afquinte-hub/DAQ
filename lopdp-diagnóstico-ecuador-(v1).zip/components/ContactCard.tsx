import React from 'react';
import { Mail, Phone, MessageCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';

interface ContactCardProps {
  onBack: () => void;
}

const ContactCard: React.FC<ContactCardProps> = ({ onBack }) => {
  const phoneNumber = "593984471098";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent("Hola, he realizado el diagnóstico LOPDP y me interesa agendar una cita para revisar mis resultados y recibir asesoría.")}`;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-8 duration-700 w-full">
      <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/60 border border-slate-100 overflow-hidden relative">
        
        {/* Header Section */}
        <div className="bg-slate-900 p-8 md:p-10 text-white text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400 via-slate-900 to-slate-900"></div>
          <div className="relative z-10">
            <h2 className="text-3xl md:text-4xl font-extrabold mb-4">¿Qué sigue ahora?</h2>
            <p className="text-slate-300 text-lg max-w-2xl mx-auto leading-relaxed">
              El resultado que acabas de obtener es una evaluación inicial.
            </p>
          </div>
        </div>

        <div className="p-8 md:p-12 space-y-8 text-slate-700">
          
          {/* Main Context */}
          <div className="prose prose-slate max-w-none">
            <p className="text-lg leading-relaxed">
              En la práctica, la mayoría de las empresas en Ecuador presentan brechas importantes que no siempre son visibles en un autodiagnóstico.
            </p>
            <p className="text-lg leading-relaxed mt-4">
              La <strong>Ley Orgánica de Protección de Datos Personales</strong> y su Reglamento exigen evidencias formales, procesos claros y controles reales. Un error, una queja o una inspección puede generar multas, sanciones y afectación reputacional.
            </p>
            
            <div className="bg-blue-50 border-l-4 border-blue-600 p-6 my-8 rounded-r-xl">
              <h3 className="font-bold text-blue-900 text-lg mb-2">👉 La buena noticia</h3>
              <p className="text-blue-800">
                Estas brechas pueden corregirse de forma ordenada y sin afectar la operación de tu negocio.
              </p>
            </div>
          </div>

          {/* Services List */}
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-6">¿Cómo podemos ayudarte?</h3>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                "Diagnóstico profesional completo",
                "Plan de implementación paso a paso",
                "Elaboración de políticas obligatorias",
                "Análisis de riesgos y EIPD",
                "Acompañamiento legal y técnico"
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                  <span className="font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <hr className="border-slate-100" />

          {/* Contact Section */}
          <div className="text-center">
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Contáctanos y protege tu empresa</h3>
            <p className="text-slate-500 mb-8">
              Si deseas conocer exactamente qué debes corregir, cuánto tiempo tomará y cómo hacerlo correctamente, conversemos.
            </p>

            <div className="flex flex-col md:flex-row justify-center gap-6 mb-10">
              <a href="mailto:aquinterosvaca@gmail.com" className="flex items-center justify-center gap-3 text-slate-600 hover:text-blue-700 transition-colors p-4 bg-slate-50 rounded-xl hover:bg-blue-50">
                <div className="bg-white p-2 rounded-full shadow-sm">
                  <Mail className="w-5 h-5" />
                </div>
                <span className="font-medium">aquinterosvaca@gmail.com</span>
              </a>
              <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-3 text-slate-600 hover:text-green-700 transition-colors p-4 bg-slate-50 rounded-xl hover:bg-green-50">
                <div className="bg-white p-2 rounded-full shadow-sm">
                  <Phone className="w-5 h-5" />
                </div>
                <span className="font-medium">+593 984 471 098</span>
              </a>
            </div>

            <a 
              href={whatsappUrl}
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full md:w-auto inline-flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 text-white text-lg font-bold py-4 px-12 rounded-xl transition-all shadow-lg shadow-green-600/30 transform hover:-translate-y-1 mb-6"
            >
              <MessageCircle className="w-6 h-6" />
              Agendar una cita
            </a>
          </div>
        </div>
        
        {/* Footer Back Button */}
        <div className="bg-slate-50 p-4 text-center border-t border-slate-100">
          <button 
            onClick={onBack}
            className="inline-flex items-center gap-2 text-slate-400 hover:text-slate-600 text-sm font-medium transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver a los resultados
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactCard;