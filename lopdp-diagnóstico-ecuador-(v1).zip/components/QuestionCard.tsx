import React from 'react';
import { Question } from '../types';
import { ArrowRight, CheckCircle2, ChevronRight } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  onAnswer: (value: number) => void;
  onNext: () => void;
  selectedParams?: number;
}

const QuestionCard: React.FC<QuestionCardProps> = ({ question, onAnswer, onNext, selectedParams }) => {
  
  const options = [
    { value: 1, label: "No implementado / Desconozco" },
    { value: 2, label: "Planificado pero no iniciado" },
    { value: 3, label: "En proceso de implementación" },
    { value: 4, label: "Implementado parcialmente" },
    { value: 5, label: "Totalmente implementado y documentado" },
  ];

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <h2 className="text-xl md:text-2xl font-bold text-slate-800 mb-2 leading-tight">
        {question.text}
      </h2>
      <p className="text-slate-500 mb-8 text-sm md:text-base whitespace-pre-line leading-relaxed">
        {question.description}
      </p>

      <div className="space-y-3 mb-8">
        {options.map((option) => {
          const isSelected = selectedParams === option.value;
          return (
            <button
              key={option.value}
              onClick={() => onAnswer(option.value)}
              className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 flex items-center group relative overflow-hidden
                ${isSelected 
                  ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-md ring-1 ring-blue-600' 
                  : 'border-slate-200 hover:border-blue-400 hover:bg-slate-50 text-slate-700'
                }`}
            >
              <div className={`
                flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border mr-4 text-sm font-bold transition-colors
                ${isSelected 
                  ? 'bg-blue-600 border-blue-600 text-white' 
                  : 'bg-white border-slate-300 text-slate-500 group-hover:border-blue-400 group-hover:text-blue-500'
                }
              `}>
                {option.value}
              </div>
              <span className="font-medium flex-grow">{option.label}</span>
              {isSelected && <CheckCircle2 className="w-5 h-5 text-blue-600 animate-in zoom-in duration-200" />}
            </button>
          );
        })}
      </div>

      <div className="flex justify-end">
        <button
          onClick={onNext}
          disabled={!selectedParams}
          className={`
            flex items-center gap-2 py-3 px-8 rounded-xl font-bold text-lg transition-all duration-300
            ${selectedParams 
              ? 'bg-blue-900 hover:bg-blue-800 text-white shadow-lg hover:shadow-blue-900/30 transform hover:-translate-y-1' 
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }
          `}
        >
          Siguiente
          <ChevronRight className={`w-5 h-5 ${selectedParams ? 'animate-pulse' : ''}`} />
        </button>
      </div>
    </div>
  );
};

export default QuestionCard;