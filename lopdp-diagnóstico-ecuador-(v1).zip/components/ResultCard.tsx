import React from 'react';
import { ResultLevel } from '../types';
import { AlertTriangle, CheckCircle, AlertOctagon, Info, FileText, CalendarCheck } from 'lucide-react';

interface ResultCardProps {
  result: ResultLevel;
  score: number;
  onReset: () => void;
  onContactRequest: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, score, onContactRequest }) => {
  
  const phoneNumber = "593984471098";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent("Hola, he realizado el diagnóstico LOPDP y quisiera solicitar la asesoría gratuita de 30 minutos.")}`;

  // Dynamic color mapping based on the result.colorClass string
  const getColorClasses = (color: string) => {
    switch (color) {
      case 'red':
        return {
          bg: 'bg-red-50',
          border: 'border-red-200',
          text: 'text-red-900',
          accent: 'text-red-600',
          badge: 'bg-red-100 text-red-700',
          button: 'bg-red-600 hover:bg-red-700',
          icon: <AlertOctagon className="w-12 h-12 text-red-600" />
        };
      case 'orange':
        return {
          bg: 'bg-orange-50',
          border: 'border-orange-200',
          text: 'text-orange-900',
          accent: 'text-orange-600',
          badge: 'bg-orange-100 text-orange-800',
          button: 'bg-orange-600 hover:bg-orange-700',
          icon: <AlertTriangle className="w-12 h-12 text-orange-600" />
        };
      case 'amber':
        return {
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          text: 'text-amber-900',
          accent: 'text-amber-600',
          badge: 'bg-amber-100 text-amber-800',
          button: 'bg-amber-500 hover:bg-amber-600',
          icon: <Info className="w-12 h-12 text-amber-600" />
        };
      case 'emerald':
        return {
          bg: 'bg-emerald-50',
          border: 'border-emerald-200',
          text: 'text-emerald-900',
          accent: 'text-emerald-600',
          badge: 'bg-emerald-100 text-emerald-800',
          button: 'bg-emerald-600 hover:bg-emerald-700',
          icon: <CheckCircle className="w-12 h-12 text-emerald-600" />
        };
      default:
        return {
          bg: 'bg-slate-50',
          border: 'border-slate-200',
          text: 'text-slate-900',
          accent: 'text-slate-600',
          badge: 'bg-slate-100 text-slate-800',
          button: 'bg-slate-800 hover:bg-slate-900',
          icon: <Info className="w-12 h-12" />
        };
    }
  };

  const colors = getColorClasses(result.colorClass);

  return (
    <div className="animate-in fade-in zoom-in-95 duration-700">
      {/* Result Header Card */}
      <div className={`rounded-2xl border-2 ${colors.border} ${colors.bg} overflow-hidden mb-8 shadow-sm`}>
        <div className="p-6 md:p-10 text-center">
          <div className="flex justify-center mb-4">
            <div className={`p-4 rounded-full bg-white shadow-sm ring-4 ring-opacity-30 ring-white`}>
              {colors.icon}
            </div>
          </div>
          
          <div className={`inline-block px-4 py-1.5 rounded-full text-sm font-bold tracking-wide uppercase mb-3 ${colors.badge}`}>
            Puntaje: {score}/60
          </div>
          
          <h2 className={`text-3xl md:text-4xl font-extrabold mb-2 ${colors.text}`}>
            {result.title}
          </h2>
          <h3 className={`text-xl font-semibold opacity-90 mb-6 ${colors.accent} tracking-tight`}>
            {result.subtitle}
          </h3>

          <div className="w-full h-px bg-current opacity-10 my-6"></div>

          <div className="text-left space-y-6">
            <p className="text-slate-700 whitespace-pre-line leading-relaxed text-lg">
              {result.description}
            </p>

            {result.bulletPoints.length > 0 && (
              <ul className="space-y-3 bg-white/50 p-6 rounded-xl">
                {result.bulletPoints.map((point, index) => (
                  <li key={index} className="flex items-start text-slate-700">
                    <span className={`mr-3 mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${colors.button}`}></span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            )}

            <div className={`p-6 rounded-xl border ${colors.border} bg-white/60`}>
              <h4 className={`font-bold uppercase text-sm mb-3 ${colors.accent}`}>Recomendación Estratégica</h4>
              <p className="text-slate-800 whitespace-pre-line font-medium leading-relaxed">
                {result.recommendation}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-slate-900 rounded-2xl p-8 md:p-10 text-white text-center shadow-xl mb-8">
        <h3 className="text-2xl font-bold mb-4">
          ¿Desea recibir un informe completo y un plan de acción?
        </h3>
        <p className="text-slate-300 mb-8 max-w-2xl mx-auto leading-relaxed">
          Nuestros expertos pueden ayudarle a implementar la Ley de Protección de Datos, minimizar riesgos y preparar a su organización para auditorías o certificaciones.
        </p>
        
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <button 
            onClick={onContactRequest}
            className="w-full md:w-auto flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 px-8 rounded-xl transition-all transform hover:-translate-y-1 shadow-lg shadow-blue-900/50"
          >
            <FileText className="w-5 h-5" />
            <span>Solicitar Evaluación Profesional</span>
          </button>
          
          <a 
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full md:w-auto flex items-center justify-center gap-2 bg-transparent border-2 border-slate-600 hover:bg-slate-800 hover:border-slate-500 text-white font-semibold py-4 px-8 rounded-xl transition-all"
          >
            <CalendarCheck className="w-5 h-5" />
            <span>Asesoría Gratuita 30 min</span>
          </a>
        </div>
      </div>

    </div>
  );
};

export default ResultCard;